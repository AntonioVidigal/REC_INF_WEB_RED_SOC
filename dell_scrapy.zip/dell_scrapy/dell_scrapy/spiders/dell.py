import scrapy
import os
import pandas as pd

class DellSpider(scrapy.Spider):
    name = 'dell'
    #allowed_domains = ['www.dell.com']
    start_urls = [f'https://www.dell.com/pt-br/shop/notebooks-dell/sr/laptops/inspiron?page={i}&appliedRefinements=34240' for i in range(1,4)]

    if os.path.exists('dell.json'):
        os.remove('dell.json')

    def parse(self, response, **kwargs):
        for i in response.xpath('//section[@class="ps-top"]'):
            model = i.xpath('.//h3[@class="ps-title"]//a//text()').get()
            link = i.xpath('.//h3[@class="ps-title"]//a/@href').get()
            price = i.xpath('.//div[@class="ps-dell-price ps-simplified"]//text()').get()
            processor = i.xpath('.//div[@class="short-specs ps-dds-font-icon dds_processor"]//text()').get()
            os = i.xpath('.//div[@class="short-specs ps-dds-font-icon dds_disc-system"]//text()').get()
            video = i.xpath('.//div[@class="short-specs ps-dds-font-icon dds_video-card"]//text()').get()
            memory = i.xpath('.//div[@class="short-specs ps-dds-font-icon dds_memory"]//text()').get()
            hd = i.xpath('.//div[@class="short-specs ps-dds-font-icon dds_hard-drive"]//text()').get()
            screen = i.xpath('.//div[@class="ps-dds-font-icon featured-spec dds_display device-laptop"]//text()').get()
            weight = i.xpath('.//div[@class="ps-dds-font-icon featured-spec dds_weight dimensions-weight"]//text()').get()

            spec_list = ['model', 'link', 'price', processor, os, video, memory, hd, screen, weight]
            for i in range(len(spec_list)):
                if (spec_list[i]):
                    spec_list[i] = spec_list[i].replace("\n", "")
                    spec_list[i] = spec_list[i].strip(" ")


            link = link.replace("//", "https://")

            lista = {
                'Modelo': model,
                'Link': link,
                'Preço': price,
                'Processador': processor,
                'OS': os,
                'Placa de Video': video,
                'Memória Ram': memory,
                'HD': hd,
                'Tela': screen,
                'Peso': weight
            }
        
            yield lista

            