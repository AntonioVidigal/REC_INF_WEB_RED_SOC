import pandas as pd
import json

notebooks_df = pd.read_json('C:\\DEV\\dell_scrapy\\dell.json')
print(notebooks_df.head())
notebooks_df.to_excel('notebooks.xlsx')
